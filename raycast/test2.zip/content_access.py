import pygame

texture1 = pygame.image.load("textures/texture1.jpg")
texture2 = pygame.image.load("textures/texture2.jpg")
texture3 = pygame.image.load("textures/texture3.jpg")
texture4 = pygame.image.load("textures/texture4.jpg")
gun = pygame.image.load("textures/gun.png")