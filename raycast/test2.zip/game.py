import content_access as content

import math
import pygame
import logic
import grphcs

tile = 32
tile_hscale = 1.5

g = None

sensitivity = 0.002

##tiles = {'#':grphcs.texture1, '@':grphcs.texture2}
tiles = {'1':content.texture1, '2':content.texture2, '3':content.texture3, '4':content.texture4}

class Instance:
    def __init__(self,x,y):
        self.coords = list()
        self.coords = [x, y]

class Player(Instance):
    def __init__(self, x, y, angle, rot_vel, vel, fov):
        super().__init__(x,y)

        self.angle = angle
        self.rot_vel = rot_vel
        self.vel = vel
        self.controls = {
            'turn_left':pygame.K_LEFT,
            'str_right':pygame.K_d,
            'str_left':pygame.K_a,
            'turn_right':pygame.K_RIGHT,
            'forward':pygame.K_w,
            'backward':pygame.K_s
            }
        self.fov = fov


    def keyboard_movement(self, keys):
        if keys[self.controls['turn_left']]:
            self.angle+=self.rot_vel
        if keys[self.controls['turn_right']]:
            self.angle-=self.rot_vel

        if keys[self.controls['forward']]:
            self.coords[1]-=math.sin(self.angle)*self.vel
            self.coords[0]+=math.cos(self.angle)*self.vel
        if keys[self.controls['backward']]:
            self.coords[1]+=math.sin(self.angle)*self.vel
            self.coords[0]-=math.cos(self.angle)*self.vel

        if keys[self.controls['str_left']]:
            self.coords[1]-=math.sin(self.angle+math.pi/2)*self.vel*0.6
            self.coords[0]+=math.cos(self.angle+math.pi/2)*self.vel*0.6
        if keys[self.controls['str_right']]:
            self.coords[1]+=math.sin(self.angle+math.pi/2)*self.vel*0.6
            self.coords[0]-=math.cos(self.angle+math.pi/2)*self.vel*0.6

        self.angle-=(pygame.mouse.get_pos()[0]-g.WIDTH//2)*sensitivity

        self.angle = logic.normalize_angle(self.angle)




class Level:
    def __init__(self):
        self.layout = level = [
                      "11111111111111111111",
                      "1......2........1..1",
                      "1......2........1..1",
                      "113...........111..1",
                      "1..................1",
                      "1..................1",
                      "1....111111114131111",
                      "3....2....2........1",
                      "1....2....1........1",
                      "4.........2........1",
                      "3.........1........1",
                      "1..................1",
                      "1.........2........1",
                      "11111111111111111111",
                      ]


##class Tile:
##    def __init__(self, texture, id, symbol):
##        self.texture = texture
##        self.id = id
##        self.symbol = symbol
