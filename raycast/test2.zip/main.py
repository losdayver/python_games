import content_access as content
import pygame
import math
import logic
import grphcs
import game

#variables
texture_b = pygame.image.load("textures/back.jpg")
WIDTH, HEIGHT = 640,512
fps = 60
rays=128
screen = pygame.display.set_mode((WIDTH, HEIGHT))
texture_b = pygame.transform.scale(texture_b, (WIDTH, HEIGHT))

player = game.Player(100, 100, 0.4, 0.08, 5, math.pi/3)
level = game.Level()
g = grphcs.Graphics(WIDTH,HEIGHT,screen)
game.g = g

#init
pygame.init()
clock = pygame.time.Clock()
pygame.mouse.set_cursor((8,8),(0,0),(0,0,0,0,0,0,0,0),(0,0,0,0,0,0,0,0))

#main cycle
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit()
            running = False
            continue

    screen.blit(texture_b, (-1, 0))

#controls
    player.keyboard_movement(pygame.key.get_pressed())

#logic
    collisions = logic.cast_multiple(player, level.layout, game.tile, 12, rays)
    g.draw_walls_textured(player, collisions, 0.7, (0,0,0), rays)
#drawing
    sctile = 10

    for y in range(len(level.layout)):
        for x in range(len(level.layout[y])):
            if level.layout[y][x]!=".":
                pygame.draw.rect(screen, pygame.Color('white'), [x*sctile, y*sctile, sctile,sctile])


    pygame.draw.circle(screen, pygame.Color('green'), [int(player.coords[0]/game.tile*sctile), int(player.coords[1]/game.tile*sctile)], 5)
    screen.blit(content.gun, (WIDTH//2-100, HEIGHT-175))

    #print(rays)

#end

    pygame.mouse.set_pos((WIDTH//2, HEIGHT//2))
    pygame.display.flip()
    clock.tick(fps)